<div id="index-banner" class="parallax-container">
    <div class="slider">
        <ul class="slides">
            <li><img src="../dist/images/slider/slide-1.gif" class="parallax"></li>
            <li><img src="../dist/images/slider/slide-2.gif" class="parallax"></li>
            <li><img src="../dist/images/slider/slide-3.gif" class="parallax"></li>
        </ul>
    </div>
</div>