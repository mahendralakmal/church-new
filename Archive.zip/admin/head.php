<?php
//include('session.php');
//require_once('../MysqliDb.php');
//$db = new MysqliDb ('localhost', 'homestead', 'secret', 'fsnhs');
?>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no"/>
  <title>Mattumagala Sacred Heart Parish</title>

  <!-- CSS  -->
   <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato" />
  <link href="../dist/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../dist/css/admin-style.css" type="text/css" rel="stylesheet" media="screen,projection"/>
  <link href="../dist/lightbox/css/lightbox.css" rel="stylesheet">
</head>