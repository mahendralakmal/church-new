<div class="admin-nav col m2">
    <ul class="collapsible" data-collapsible="accordion">
        <li>
            <div class="collapsible-header"><a href="#" class="collection-item">Users</a></div>
            <div class="collapsible-body">
                <ul class="collection">
                    <li class="collection-item"><a href="/admin/users.php" class="collection-item">Add New User</a></li>
                    <li class="collection-item"><a href="/admin/users_approvals.php" class="collection-item">Approval</a></li>
                </ul>
            </div>
        </li>
        <li>
            <div class="collapsible-header"><a href="#" class="collection-item">Posts</a></div>
            <div class="collapsible-body">
                <ul class="collection">
                    <li class="collection-item"><a href="/admin/post.php" class="collection-item">Add Post</a></li>
<!--                    <li class="collection-item"><a href="/admin/post_approve.php" class="collection-item">Approval</a></li>-->
                </ul>
            </div>
        </li>
    </ul>
</div>